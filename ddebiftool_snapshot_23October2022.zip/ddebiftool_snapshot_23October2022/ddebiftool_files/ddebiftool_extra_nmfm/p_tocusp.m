function cusp=p_tocusp(point)
%% convert fold point to point of type cusp
%
% $Id: p_tocusp.m 309 2018-10-28 19:02:42Z jansieber $
%%
cusp=point;
cusp.kind='cusp';

end