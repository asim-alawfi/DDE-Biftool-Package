function p=dde_array_insert(p,inds,vals)
%% functional version of p(inds)=vals
%
% $Id: dde_array_insert.m 309 2018-10-28 19:02:42Z jansieber $
%
%%
p(inds)=vals;
end