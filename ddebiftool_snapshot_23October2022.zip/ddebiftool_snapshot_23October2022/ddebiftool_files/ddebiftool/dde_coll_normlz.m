function coll=dde_coll_normlz(coll)
%% normalize coll derived points
% (descended from |'coll'| kind)
%
% $Id: dde_coll_normlz.m 366 2019-07-14 21:52:54Z jansieber $
%%
end
