%%  DDE-BIFTOOL minimal_demo - Duffing oscillator with delayed feedback
% run all scripts of this for testing
% This script runs all demos files in a single run for testing purposes.
% See <html/minimal_demo.html> for the published version of the single scripts
%
% <html>
% $Id: publishdemo.m 364 2019-07-14 17:25:51Z jansieber $
% </html>
%% Description, load path and define system and run bifurcation analysis
publish('gen_sym_minimal_demo.m','evalCode',false);
publish('minimal_demo');
